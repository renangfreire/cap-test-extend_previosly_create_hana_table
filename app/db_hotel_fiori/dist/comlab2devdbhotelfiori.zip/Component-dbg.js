sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.lab2dev.dbhotelfiori.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);